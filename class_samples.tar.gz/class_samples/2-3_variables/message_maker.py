name = 'Josephina'
grade = 75

print('Here is your grade, ' + name + '!')
print(grade)

# this will throw an error
print('Your grade is a ' + grade + ', ' + name)

