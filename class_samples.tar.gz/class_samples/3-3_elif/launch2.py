print('What is your brother\'s name?')
bro_name = raw_input()

if bro_name == 'Joe':
	print('Whoa, we must be related, me too!!')
else:
	print('Oh, that\'s cool.')
