first = "Josephina"
last = "Jones"
bros = 2
sises = 1

print(first + last)
print(bros + sises)

# this throws an error
print(first + bros)
