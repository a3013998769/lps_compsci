print("Happy birthday, Ms. Fiske! J/k I hope it is not fun.")

