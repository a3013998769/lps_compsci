print("does raw_input() work here?")
myvar = raw_input()
print("yes " + myvar)


print("does input() work here?")
myvar = input()
print("yes " + myvar)
