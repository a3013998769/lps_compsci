# example

donuts = 22
people = 10
per_person = donuts / people

print(str(per_person) + " donuts per person")
