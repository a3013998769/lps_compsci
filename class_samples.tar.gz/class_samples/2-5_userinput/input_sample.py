print("How old are you?")
age = raw_input()
print("How many years will it be until you graduate from college?")
years = raw_input()

print(int(age) + int(years))
print("Cool! Did not know you were " + age)

