print("How old are you?")
age = raw_input()

month_age = 12 * int(age)
print("Whoa, you're " + str(month_age) + " months old?!")
